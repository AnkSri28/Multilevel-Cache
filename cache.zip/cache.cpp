#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include "sim.h"
// Debug switch
#define DEBUG 0


class cache{
    private:
        //void processStruct(const cache_set_t& Cache_set_t);
        cache* next_cache;
        char request;
        uint32_t ways;
        uint32_t sets;
        uint32_t addr;
        uint32_t index;
        uint32_t Tag;
        uint32_t block_offset;       
    public:
        uint32_t location_in_way;
        /////////USED WHEN REPLACEMENT IS NEEDED////////////
        char req_lx_next;
        uint32_t eject_address;
        ////////////////////////////////////////////////////
        bool hit = false;
        bool miss = false;
        uint32_t hit_tag_way;
        ////////////////////////////////////////////////////
        uint32_t lx_reads=0;
        uint32_t lx_read_misses=0;
        uint32_t lx_writes=0;
        uint32_t lx_write_misses=0;
        float lx_miss_rate=0;
        uint32_t lx_writebacks=0;
        uint32_t lx_prefetches=0;
        uint32_t mem_access_cnt=0;
        ////////////////////////////////////////////////////

        // Constructor definition
        cache(cache* nextCache, char req, uint32_t w, uint32_t s, uint32_t a,
          uint32_t idx, uint32_t tag, uint32_t blockOff)
        : next_cache(nextCache), request(req), ways(w), sets(s),
          addr(a), index(idx), Tag(tag), block_offset(blockOff) {
    }
        // Step 1: Allocate an array of pointers to cache_set_t
        cache_set_t** lx_cache = new cache_set_t*[sets];
        int** lru_counter = new int*[sets];

    void setup(){
        // Step 2: Allocate each row as an array of cache_set_t
        //printf("Hello\n");
        for (uint32_t i = 0; i < sets; i++) {
            lx_cache[i] = new cache_set_t[ways];
            lru_counter[i] = new int[ways];
        }
        for (uint32_t i = 0; i < sets; i++) {
            for (uint32_t j = 0; j < ways; ++j) {
                lx_cache[i][j].VALID_BIT = 0;
                lx_cache[i][j].DIRTY_BIT = 0;
                lx_cache[i][j].TAG = 0;
                lx_cache[i][j].ADDR = 0;
                lru_counter[i][j] = j; 
                //printf("lru_count[%d][%d]=%d\n",i,j,lru_counter[i][j]);
            }
        }
        //printf("Hello1\n");
    }    

bool DEBUG_PRINT = false; // Set to true to enable debug prints

bool request_fn(char request, uint32_t addr) {
    uint32_t idx;
    uint32_t tag;
    bool status = false;

    // Calculate index and tag from the address
    uint32_t block_offset_mask = (1 << block_offset) - 1;
    uint32_t block_offset_bits = addr & block_offset_mask;

    uint32_t idx_mask = (1 << index) - 1;
    idx = (addr >> block_offset) & idx_mask;

    tag = addr >> (index + block_offset);

    // Debugging output
    if (DEBUG_PRINT) {
        printf("================================================\n");
        printf("Address: %x, Index: %u, Block Offset: %u, Tag: %x\n", addr, idx, block_offset_bits, tag);
    }

    cache_set_t* tag_row = lx_cache[idx];

    // Check for hit in the current cache set
    for (uint32_t i = 0; i < ways; i++) {
        if (tag == tag_row[i].TAG && tag_row[i].VALID_BIT) {
            if (DEBUG_PRINT) printf("Hit in L1 cache at index %u, way %u\n", idx, i);
            hit = true;
            hit_tag_way = i;

            // LRU update
            location_in_way = lru_counter_update(idx, ways, hit_tag_way, hit);
            if (request == 'w') {
                lx_writes++;
                tag_row[location_in_way].DIRTY_BIT = 1;
                tag_row[location_in_way].ADDR = addr;
                tag_row[location_in_way].VALID_BIT = 1;

                if (DEBUG_PRINT) {
                    printf("Write hit: TAG=%x ADDR=%x DIRTY=%d\n", tag_row[location_in_way].TAG, tag_row[location_in_way].ADDR, tag_row[location_in_way].DIRTY_BIT);
                }
            } else {
                lx_reads++;
                tag_row[location_in_way].ADDR = addr;
                tag_row[location_in_way].VALID_BIT = 1;

                if (DEBUG_PRINT) {
                    printf("Read hit: TAG=%x ADDR=%x DIRTY=%d\n", tag_row[location_in_way].TAG, tag_row[location_in_way].ADDR, tag_row[location_in_way].DIRTY_BIT);
                }
            }
            return true; // Early return on hit
        }
    }

    // Miss handling
    if (next_cache != nullptr && (next_cache->sets > 0) && (next_cache->ways > 0)) { 
        location_in_way = lru_counter_update(idx, ways); // Update LRU
        if (tag_row[location_in_way].DIRTY_BIT == 1 && tag != tag_row[location_in_way].TAG) {
            if (DEBUG_PRINT) printf("TRYING to EVICT\n");
            if (DEBUG_PRINT) {
                printf("EVICT: TAG=%x ADDR=%x DIRTY=%d\n", tag_row[location_in_way].TAG, tag_row[location_in_way].ADDR, tag_row[location_in_way].DIRTY_BIT);
            }
            lx_writebacks++;
            req_lx_next = 'w';
            eject_address = tag_row[location_in_way].ADDR;

            bool l2_hit = next_cache->request_fn(req_lx_next, eject_address);
            if (DEBUG_PRINT) {
                printf("L2 Miss Handling: Ejecting Address=%x, L2 Hit=%d\n", eject_address, l2_hit);
            }
            mem_access_cnt++;
            tag_row[location_in_way].ADDR = addr;
            tag_row[location_in_way].DIRTY_BIT = 0; // Reset dirty after eviction
        }

        // Handle the read request to L2
        if (DEBUG_PRINT) printf("TRYING to READ from L2\n");
        req_lx_next = 'r';
        eject_address = addr;
        bool l2_read = next_cache->request_fn(req_lx_next, eject_address);
        if (DEBUG_PRINT) printf("ALREADY READ from L2\n");

        if (DEBUG_PRINT) {
            printf("Requesting L2: Address=%x, Read Result=%d\n", addr, l2_read);
        }

        if (request == 'w') {   
            lx_writes++;
            lx_write_misses++;
            tag_row[location_in_way].DIRTY_BIT = 1;
            tag_row[location_in_way].TAG = tag; // Update L1
            tag_row[location_in_way].VALID_BIT = 1;
            tag_row[location_in_way].ADDR = addr;

            if (DEBUG_PRINT) {
                printf("Write to L1: TAG=%x, ADDR=%x, DIRTY=1\n", tag, addr);
            }
        } else {
            lx_read_misses++;
            lx_reads++;
            tag_row[location_in_way].DIRTY_BIT = 0; // Reset dirty on read
            tag_row[location_in_way].TAG = tag; // Update L1
            tag_row[location_in_way].VALID_BIT = 1;  
            tag_row[location_in_way].ADDR = addr;

            if (DEBUG_PRINT) {
                printf("Read to L1: TAG=%x, ADDR=%x, DIRTY=0\n", tag, addr);
            }
        }
        return true; // Return after handling L2
    } else {
        // If both L1 and L2 miss, handle memory access
        mem_access_cnt++; // Increment memory access count
        location_in_way = lru_counter_update(idx, ways); // LRU update
        if (request == 'w') {
            lx_writes++;
            lx_write_misses++;
            tag_row[location_in_way].DIRTY_BIT = 1;
            tag_row[location_in_way].VALID_BIT = 1;
            tag_row[location_in_way].ADDR = addr;
            tag_row[location_in_way].TAG = tag;

            if (DEBUG_PRINT) {
                printf("Write to Memory: TAG=%x, ADDR=%x\n", tag, addr);
            }
        } else {
            lx_reads++;
            lx_read_misses++;
            tag_row[location_in_way].DIRTY_BIT = 0; // Reset dirty on read
            tag_row[location_in_way].VALID_BIT = 1;
            tag_row[location_in_way].ADDR = addr;
            tag_row[location_in_way].TAG = tag;

            if (DEBUG_PRINT) {
                printf("Read to Memory: TAG=%x, ADDR=%x\n", tag, addr);
            }
        }
    }

    return status; // Final return status
}


uint32_t lru_counter_update(uint32_t index, uint32_t way, uint32_t hit_way = 0, bool hit = false) {
    // Initialize location for the least recently used (LRU)
    uint32_t location_in_way = 0;
    // If there is a hit
    // If there is a hit
    if (hit) {
        // Update the hit way to be the most recently used (MRU)
        uint32_t hit_lru = lru_counter[index][hit_way];
        if (DEBUG) {
            printf("HIT_LRU=%d, lru_counter[%d][%d]=%d\n", hit_lru, index, hit_way, lru_counter[index][hit_way]);
        }

        // Set the hit way's counter to 0 (most recently used)
        lru_counter[index][hit_way] = 0; 

        // Update other counters
        for (uint32_t i = 0; i < way; i++) {
            if (i != hit_way) {
                if (lru_counter[index][i] < hit_lru) {
                    lru_counter[index][i]++; // Increment the counter for other ways
                }
                
                if (DEBUG) {
                    printf("After HIT: lru_counter[%d][%d]=%d\n", index, i, lru_counter[index][i]);
                }
            }
        }
        
        return hit_way; // Return the hit way
    } else {
        // Update for a miss: find the least recently used (LRU) way
        for (uint32_t i = 0; i < way; i++) {
            lru_counter[index][i]++;
        }
        // Identify the LRU way
        for (uint32_t j = 0; j < way; j++) {
            if (lru_counter[index][j] == way) {
                lru_counter[index][j] = 0; 
                location_in_way = j;
            }
        }
        // Debug print for all LRU counters
        if (DEBUG) {
            for (uint32_t j = 0; j < way; j++) {
                printf("LRU[%d][%d]=%d\n", index, j, lru_counter[index][j]);
            }
        }       
        return location_in_way; // Return the location of the replaced way
    }
}
};